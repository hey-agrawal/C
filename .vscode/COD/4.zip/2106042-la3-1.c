/*greater of two number
AUTHORE NAME-PRASOON AGRAWAL*/
#include <stdio.h>
int main()
{
    int a,b;
    printf("entre the two numbers");
    scanf("%d%d",&a,&b);
    if(a>b)
    printf("the gretaer number is%d",a) ;
    else
    printf("the greater number is%d",b);
    return 0;

}