/*odd even
AUTHORE NAME-PRASOON AGRAWAL*/
#include<stdio.h>
int main()
{
    int a;
    printf("entre the number");
    scanf("%d",&a);
    if 
    (a%2==0)
    printf("the number is even number");
    else 
    printf("the number is odd");
    return 0;
        

}